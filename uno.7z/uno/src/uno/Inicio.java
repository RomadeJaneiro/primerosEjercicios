package uno;

public class Inicio {

	public static void main(String[] args) {
		// Comentario de una linea
		/*
		 * Comentario de
		 * varias lineas
		 */
		
		System.out.println("Hola mundo\nRoma");

	}

}
