package uno;

import java.util.Scanner;

public class Inicio {

	public static void main(String[] args) {
		// Comentario de una linea
		/*
		 * Comentario de
		 * varias lineas
		 */
		
		System.out.println("Ingrese numero: ");
		Scanner teclado = new Scanner (System.in); 
		int numero;
		numero = teclado.nextInt();
		System.out.println("El cuadrado es: ");
		System.out.println(numero*numero);
	}

}
